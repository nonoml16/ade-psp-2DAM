package com.salesianostriana.dam.ej03herenciamappedsuperclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej03HerenciaMappedSuperclassApplicationTests {

	@Test
	void contextLoads() {
	}

}
