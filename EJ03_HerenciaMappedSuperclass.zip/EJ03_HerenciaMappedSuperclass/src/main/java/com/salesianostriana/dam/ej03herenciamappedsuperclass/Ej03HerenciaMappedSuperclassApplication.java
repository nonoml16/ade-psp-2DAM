package com.salesianostriana.dam.ej03herenciamappedsuperclass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej03HerenciaMappedSuperclassApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej03HerenciaMappedSuperclassApplication.class, args);
	}

}
