package com.salesianostriana.dam.ej02asociaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej02AsociacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej02AsociacionesApplication.class, args);
	}

}
