package com.salesianostriana.dam.ej02asociaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej02AsociacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
