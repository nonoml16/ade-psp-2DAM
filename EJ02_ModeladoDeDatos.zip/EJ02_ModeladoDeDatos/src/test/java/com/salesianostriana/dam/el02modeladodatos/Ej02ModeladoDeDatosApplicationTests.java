package com.salesianostriana.dam.el02modeladodatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej02ModeladoDeDatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
