package com.salesianostriana.dam.el02modeladodatos.entities.repositories;

import com.salesianostriana.dam.el02modeladodatos.entities.models.CursoOnline;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoOnlineRepositorio extends JpaRepository<CursoOnline, Long> {
}
