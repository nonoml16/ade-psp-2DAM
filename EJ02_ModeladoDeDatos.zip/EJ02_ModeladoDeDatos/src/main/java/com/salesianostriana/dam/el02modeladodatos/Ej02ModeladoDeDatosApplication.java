package com.salesianostriana.dam.el02modeladodatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej02ModeladoDeDatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej02ModeladoDeDatosApplication.class, args);
	}

}
