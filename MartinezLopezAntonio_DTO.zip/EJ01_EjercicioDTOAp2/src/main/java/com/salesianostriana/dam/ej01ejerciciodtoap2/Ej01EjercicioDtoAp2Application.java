package com.salesianostriana.dam.ej01ejerciciodtoap2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej01EjercicioDtoAp2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej01EjercicioDtoAp2Application.class, args);
	}

}
