package com.salesianostriana.dam.ej01ejerciciodto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej01EjercicioDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
